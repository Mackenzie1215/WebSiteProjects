package net.cit382.hagerty_ice3;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

import java.text.DecimalFormat;

public class CalculateActivity extends AppCompatActivity {
private Double dbMealTotal;
    private Double dbTipPercentage;
    private Double calculation;
    String groupChoice;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calculate);
        final Button button = findViewById(R.id.btnCalculate);
        button.setOnClickListener(new View.OnClickListener() {

            //Text view for the results
            final TextView result = ((TextView)findViewById(R.id.txtTotalTip));

            public void onClick(View v) {

                //get the meal total  and set it to dbMealTotal
                final EditText txtMealTotal = (EditText)findViewById(R.id.txtTotalBill);
                dbMealTotal =Double.parseDouble(txtMealTotal.getText().toString());

                //get the tip amount and calculate the total tip.
                final Spinner taxSpinner = (Spinner)findViewById(R.id.txtTipPercent);
                groupChoice = taxSpinner.getSelectedItem().toString();
                final Double taxAmount = (dbMealTotal * (Double.parseDouble(groupChoice))/100);

                DecimalFormat currency = new DecimalFormat ("$#,###.##");
                result.setText(currency.format(taxAmount));
                // Code here executes on main thread after user presses button
                }});

    }
}
