import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.NodeList;
import org.w3c.dom.Node;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import java.util.Stack;
public class Suduku2 {
//
    private int[][] board;
    //creating board to run through constraints

    private Stack<int[][]> stackOfBoards = new Stack<>();    
    //creating our stack
   
    ////constraints for puzzle borrowed and modified from Sylvain Saurel 
    // @https://medium.com/@ssaurel/build-a-sudoku-solver-in-java-part-1-c308bd511481
    public static final int EMPTY = 0; // empty cell
    public static final int SIZE = 4;
  public Suduku2(int[][] board) {
        this.board = new int[SIZE][SIZE];
        
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                this.board[i][j] = board[i][j];
         }
     } 
}
//see if a possible number is in its row
    private boolean isInRow(int row, int number) {
        for (int i = 0; i < SIZE; i++)
            if (board[row][i] == number)
                return true;
        
        return false;
    }
    
    // we check if a possible number is already in a column
    private boolean isInCol(int col, int number) {
        for (int i = 0; i < SIZE; i++)
            if (board[i][col] == number)
                return true;
        
        return false;
    }
    
    // we check if a possible number is in its 2x2 box
    private boolean isInBox(int row, int col, int number) {
        int r = row - row % 2;
        int c = col - col % 2;
        
        for (int i = r; i < r + 2; i++)
            for (int j = c; j < c + 2; j++)
                if (board[i][j] == number)
                    return true;
        
        return false;
    }
    
    // combined method to check if a number possible to a row,col position is ok
    private boolean isOk(int row, int col, int number) {
        return !isInRow(row, number)  &&  !isInCol(col, number)  &&  !isInBox(row, col, number);
    }
 public boolean solve1(){
    //migrate throughout the array to find empty slots
    for (int row = 0; row < SIZE; row++) {     
         for (int col = 0; col < SIZE; col++) {
      
        // we start with the first open cell
        if (board[row][col] == EMPTY) {
            // we try possible numbers
            for (int number = 1; number <= SIZE; number++) {
 /* these commented out print statements outprint which [row][col]
    **    is being tested ,which number is being tested and if it works
    **    .....just helped me get the code working and figure it will help the reader to understand
    **    whats going on
    **   */

 /* System.out.println("row "+ row);
    System.out.println("col " + col);
    System.out.println(number); */
              if (isOk(row, col, number)) {
 // System.out.println("works");

                // number ok. it respects sudoku constraints
                board[row][col] = number;

                // if it fits the constraints the board gets added to the stack
                stackOfBoards.push(board);  
                //we equal the board to the board at the top of the stack
                board = stackOfBoards.peek();

                    //if nothing got added to the [row][col] then that means no number fits the constraints
                    if (board[row][col]==0){

                           // so while the stack is not empty
                           while(!stackOfBoards.isEmpty()){

                                //we pop the top value off the stack 
                                stackOfBoards.pop();

                                //and set the board equal to the next posibility
                                  board = stackOfBoards.peek();
                            }
                        }
                    }
                }
            }
        }
    //suduku board solved
    }return true;
} 

   public void display() {
        for (int i = 0; i < SIZE; i++) {
            for (int j = 0; j < SIZE; j++) {
                System.out.print(" " + board[i][j]);
            }
        
            System.out.println();
        }
        
        System.out.println();
    }



public static void main(String[] args){
try{
       
        //array matrix created
    int [][] puzzle = new int [4][4];

        //READING THE XML FILE WITH A DOM PARSE
        File fXmlFile = new File("/Users/macke/OneDrive/Documents/sudukuTxt.xml");
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document sudukuFile = dBuilder.parse(fXmlFile);
sudukuFile.getDocumentElement().normalize();

//seperating the elements in the document based on "field" since each set of elements starts with field and storing them as nodes in a list
NodeList sList = sudukuFile.getElementsByTagName("field");
  
//This is the for loop to run a pointer through the xml file and locate the numbers we will need 
    for (int temp = 0; temp < sList.getLength(); temp++) {

        Node sNode = sList.item(temp);
                

        if (sNode.getNodeType() == Node.ELEMENT_NODE) {

            Element sElement = (Element) sNode;

//converts the elements "index and value" from elements into integers
  int index = (Integer.parseInt(sElement.getElementsByTagName("index").item(0).getTextContent()));
  int value = (Integer.parseInt(sElement.getElementsByTagName("value").item(0).getTextContent()));


//fills in the array with elements from the XML file
for (int k = 0; k < 16;){

for ( int i =0; i < 4; i++ ){

    for ( int j = 0; j < 4; j++ ){
        if (index ==(k))
            puzzle[i][j] = value;
            k++;

}
}
}
}
}


//we put that array into our sudoku board to run it through the constraints
        Suduku2 finalPuzzle = new Suduku2(puzzle);
 System.out.println("puzzle to be solved");
        //display the unsolved board
        finalPuzzle.display();

if (finalPuzzle.solve1()){
    System.out.println("solved puzzle");
            //display the solved board
            finalPuzzle.display();

        }
                 } catch (Exception e) {
            e.printStackTrace();
            }

    
}
}

