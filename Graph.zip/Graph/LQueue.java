package Graph;

import java.util.Collection;
import java.util.Iterator;
import java.util.Queue;

public class LQueue<T>implements Queue<T>{
	
	private int size;
	private QueueNode<T> front;
	private QueueNode<T> back;
	
	
	
	
	
	public LQueue(){

		front = back = null;
		size = 0;
	}
	

	public T dequeue() {
		if(!isEmpty()) {
			T data =  (T) (new QueueNode(front)).getData();
			front = front.getNext();
			size--;
			return data;
		}
			
		return null;
	}


	public void enqueue(T e) {
		if(this.isEmpty()) {
			front = back = new QueueNode(e, null);
			size = 1;
		}
		else {
		//QueueNode<T> temp = new QueueNode(e, null);
		back.setNext(new QueueNode(e, null));
		back = back.getNext();
		size++;
		}
		
	}


	public T peek() {
		if(!isEmpty()) 
			return  (T) (new QueueNode(front)).getData();
		return null;
	}

	@Override
	public int size() {
		return size;
	}

	@Override
	public boolean isEmpty() {
		return size == 0;
	}

	
	private class QueueNode<S> {

		private S data;
		private QueueNode<S> next;
		
		
		public QueueNode(S data, QueueNode<S> next) {
			super();
			this.data = data;
			this.next = next;
		}
		
		/**copy constructor
		 * 
		 * @param next
		 */
		public QueueNode(QueueNode<S> node) {
			super();
			this.data = node.data;
			this.next = node.next;
		}
		
		public QueueNode(S data) {
			super();
			this.data = data;
			this.next = null;
		}
		
		
		public QueueNode() {
			super();
			this.data = null;
			this.next = null;
		}	
		


		public S getData() {
			return data;
		}

		public void setData(S data) {
			this.data = data;
		}

		public QueueNode<S> getNext() {
			return next;
		}

		public void setNext(QueueNode<S> next) {
			this.next = next;
		}

		@Override
		public String toString() {
			return data.toString();
		}
   
		
		
		
}


	@Override
	public boolean contains(Object o) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public Object[] toArray() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public <T> T[] toArray(T[] a) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public boolean remove(Object o) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean containsAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean addAll(Collection<? extends T> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean removeAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean retainAll(Collection<?> c) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public void clear() {
		// TODO Auto-generated method stub
		
	}


	@Override
	public boolean add(T e) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public boolean offer(T e) {
		// TODO Auto-generated method stub
		return false;
	}


	@Override
	public T remove() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public T poll() {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public T element() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
}

