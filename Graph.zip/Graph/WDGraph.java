package Graph;


import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/**
 * T is required to have overridden the method equal
 * 
 * @author bgolshan && Mackenzie Hagerty
 *
 * @param <T>
 */
public class WDGraph<T> implements GraphADT<T> {

	private static int CAPACITY = 2;
	private double[][] adjMatrix;
	private int numEdges;
	private int numVertices;
	private T[] vertices;
	private final double INFINITY = Double.POSITIVE_INFINITY;

	@SuppressWarnings("unchecked")
	public WDGraph(int capacity) {
		numVertices = 0;
		numEdges = 0;
		CAPACITY = capacity;
		adjMatrix = new double[capacity][capacity];
		vertices = (T[]) new Object[capacity];
		for (int i = 0; i < adjMatrix.length; i++) {
			for (int j = 0; j < adjMatrix[i].length; j++) {
				adjMatrix[i][j] = INFINITY;
			}

		}
	}

	public WDGraph() {
		this(CAPACITY);
	}

	@Override
	public int numVertices() {
		return numVertices;
	}

	@Override
	public int numEdges() {
		return numEdges;
	}

	@Override
	public void addVertex(T vertex) {
		if (numVertices == CAPACITY)
			expand();

		if (!existVertex(vertex)) {
			vertices[numVertices] = vertex;
			numVertices++;
		}

	}

	@SuppressWarnings("unchecked")
	private void expand() {
		int newCapacity = 2 * CAPACITY;
		double[][] newAdjMatrix = new double[newCapacity][newCapacity];
		T[] newVertices = (T[]) new Object[newCapacity];

		for (int i = 0; i < numVertices; i++) {
			newVertices[i] = vertices[i];
		}

		for (int i = 0; i < newAdjMatrix.length; i++) {
			for (int j = 0; j < newAdjMatrix[i].length; j++) {
				newAdjMatrix[i][j] = INFINITY;
			}
		}

		for (int i = 0; i < numVertices; i++) {
			for (int j = 0; j < numVertices; j++) {
				newAdjMatrix[i][j] = adjMatrix[i][j];
			}
		}

		CAPACITY = newCapacity;
		adjMatrix = newAdjMatrix;
		vertices = newVertices;

	}

	public String toString() {
		String result = "";

		int GAP = 7;
		if (isEmpty())
			return result;

		result += String.format("%7s", "");
		for (int i = 0; i < numVertices; i++) {
			result += String.format("%7s", vertices[i]);
		}

		result += "\n";
		for (int i = 0; i < numVertices; i++) {
			result += String.format("%7s", vertices[i]);

			for (int j = 0; j < numVertices; j++) {
				if (adjMatrix[i][j] == INFINITY)
					result += String.format("%" + GAP + "s", '\u221e');
				else
					result += String.format("%7.0f", adjMatrix[i][j]);
			}
			result += "\n";
		}

		return result;
	}

	/**
	 * The object type T should have overridden the .equals method
	 * 
	 * @param vertex
	 * @return only if the vertex already in graph
	 */
	private boolean existVertex(T vertex) {
		for (int i = 0; i < numVertices; i++) {
			if (vertex.equals(vertices[i]))
				return true;
		}
		return false;
	}

	@Override
	public void removeVertex(T vertex) {
		int index = vertexIndex(vertex);
		if (index == -1)
			return;

		int numEdgesRemoved = 0;
		for (int i = 0; i < numVertices; i++) {
			if (adjMatrix[index][i] != INFINITY)
				numEdgesRemoved++;
			if (adjMatrix[i][index] != INFINITY)
				numEdgesRemoved++;
		}

		numEdges -= numEdgesRemoved;

		// shift the columns left
		for (int col = index; col < numVertices - 1; col++) {
			for (int row = 0; row < numVertices; row++) {
				adjMatrix[row][col] = adjMatrix[row][col + 1];
			}
		}

		// shift the rows up
		for (int row = index; row < numVertices - 1; row++) {
			for (int col = 0; col < numVertices; col++) {
				adjMatrix[row][col] = adjMatrix[row + 1][col];
			}
		}

		// set last row and last columns to infinity
		for (int i = 0; i < numVertices; i++) {
			adjMatrix[numVertices - 1][i] = INFINITY;
			adjMatrix[i][numVertices - 1] = INFINITY;
		}
		// move vertices to the left
		for (int i = index; i < numVertices - 1; i++) {
			vertices[i] = vertices[i + 1];
		}
		vertices[numVertices - 1] = null; // nullify the last value
		numVertices--;

	}

	private int vertexIndex(T vertex) {
		for (int i = 0; i < numVertices; i++)
			if (vertices[i].equals(vertex))
				return i;

		return -1;
	}

	@Override
	public void addEdge(T fromVertex, T toVertex, double weight) {
		if (this.existVertex(fromVertex) && this.existVertex(toVertex) && fromVertex != toVertex && weight >= 0) {
			if (!this.existEdge(fromVertex, toVertex))
				numEdges++;
			adjMatrix[vertexIndex(fromVertex)][vertexIndex(toVertex)] = weight;
		}

	}

	@Override
	public boolean existEdge(T fromVertex, T toVertex) {
		return (this.existVertex(fromVertex) && this.existVertex(toVertex)
				&& adjMatrix[vertexIndex(fromVertex)][vertexIndex(toVertex)] != INFINITY);
	}

	@Override
	public void removeEdge(T fromVertex, T toVertex) {
		if (this.existVertex(fromVertex) && this.existVertex(toVertex) && existEdge(fromVertex, toVertex)) {
			numEdges--;
			adjMatrix[vertexIndex(fromVertex)][vertexIndex(toVertex)] = INFINITY;
		}
	}

	@Override
	public boolean isEmpty() {
		return numVertices == 0;
	}

	@Override
	public int numComponents() {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean existPath(T fromVertex, T toVertex) {
		if (!existVertex(fromVertex) || !existVertex(toVertex))
			return false;

		boolean[] visited = new boolean[numVertices];
		LQueue<T> que = new LQueue<T>();
		T tempVertex;
		List<T> ngbrs;

		que.enqueue(fromVertex);
		boolean done = false;
		visited[vertexIndex(fromVertex)] = true;

		while (!que.isEmpty() && !done) {
			if (que.peek().equals(toVertex)) {
				done = true;
				break;
			}
			tempVertex = que.dequeue();
			ngbrs = neighbors(tempVertex);
			for (T ver : ngbrs) {
				if (!visited[vertexIndex(ver)]) {
					visited[vertexIndex(ver)] = true;
					que.enqueue(ver);
				}
			}

		}

		return done;
	}

	@Override
	public ArrayList<T> path(T fromVertex, T toVertex) {
		// TODO Auto-generated method stub
		return null;
	}

	@SuppressWarnings("unused")
	private T vertexName(int Index) {
		int w = 0;
		for (int i = 0; i < numVertices; i++) {
			if (vertexIndex(vertices[i]) == Index) {
				return vertices[i];
			}
		}
		return null;

	}

//Dijkstra shortest path algorithm
	public ArrayList<T> shortestPath(T fromVertex, T toVertex) throws IOException {

		ArrayList<T> list = new ArrayList<T>();
		Set<Integer> Q = new HashSet<Integer>();
		double[] dist = new double[numVertices];
		int[] prev = new int[numVertices];
		double minSoFar = (int) INFINITY;
		ArrayList<Integer> Path = new ArrayList<Integer>();
		int u = 0;
		int v = 0;
		int alt = 0;

		@SuppressWarnings("resource")
		PrintWriter writer = new PrintWriter("directions.dat", "UTF-8");


		
//set all values in prev[] to -1,set all values in dist[] to INFINITY, and put all verticies into the queue
		for (int i = 0; i < numVertices; i++) {
			prev[i] = -1;
			dist[i] = INFINITY;
			Q.add(i);
		}
//set the start distance to 0
		dist[vertexIndex(fromVertex)] = 0;

//while the queue is not empty we look for the value in the q with the smallest distance from 
//our current vertex and set it to u
		while (!Q.isEmpty()) {
			minSoFar = (int) INFINITY;
			for (int i : Q) {
				if (dist[i] < minSoFar) {
					minSoFar = dist[i];
					u = i;
				}
			}
//remove our vertex from the Queue
			Q.remove(u); // 15

//List shows our neighbors to our current point and makes sure they are all still in queue
			list = (ArrayList<T>) neighbors((T) vertexName(u));

//goes through the nighbors in list to get the neighbors that are still in the queue
			for (T i : list) {
				if (Q.contains(vertexIndex(i))) {

//we set v to our index of the neighbor vertex
					v = vertexIndex(i);

//we set alt to our current traveled distance + the distance to the next point
					alt = (int) (dist[u] + adjMatrix[u][v]);

//if alt is less then the distance from our start to vertex v, then we set our distance to alt.
//while also setting our prev array at index v to equal u so that it can track our path
					if (alt < dist[v]) {
						dist[v] = alt;
						prev[v] = u;
					}
				}
			}
		}
//add our first value to our final path
		Path.add(vertexIndex(toVertex));

//set i to start at the vertexIndex of our destination
		int i = (vertexIndex(toVertex));

//when prev[i] = -1 then we have found our path.

		while (prev[i] != -1) {
			i = prev[i];
			Path.add(i);
		}

//Outprint Statement to Show our path/ total distance traveled.		
		//writes statements to both standard output and "directions.dat" file
		System.out.println("\nShortest Path From " + fromVertex + " To " + toVertex);
		writer.println("\nShortest Path From " + fromVertex + " To " + toVertex);
		System.out.println("The distance between the two is " + dist[vertexIndex(toVertex)] + " Feet\n");
		writer.println("The distance between the two is " + dist[vertexIndex(toVertex)] + " Feet\n");
		
// put path into an array		
		int j = Path.size() - 1;

//out prints our path
		for (i = 0; i < Path.size(); i++) {
			if (vertexName(Path.get(j)) == toVertex) {
				System.out.println(vertexName(Path.get(j)) + " ------Is the Destination");
				writer.println(vertexName(Path.get(j)) + " ------Is the Destination");
			} else if (vertexName(Path.get(j)) == fromVertex) {
				System.out.println(vertexName(Path.get(j)) + "------ Is the Origion");
				writer.println(vertexName(Path.get(j)) + "------ Is the Origion");
			} else if (vertexName(Path.get(j)) != fromVertex && vertexName(Path.get(j)) != toVertex) {
				System.out.println(vertexName(Path.get(j)));
				writer.println(vertexName(Path.get(j)));
			}
			j--;

		}
		writer.close();
		return list;
	} ////End of shortest path Method

	@Override
//method to find neighbors or a given vertex
	public List<T> neighbors(T vertex) {
		ArrayList<T> list = new ArrayList<T>();

		if (!existVertex(vertex))
			return null;
		int index = vertexIndex(vertex);

		for (int i = 0; i < numVertices; i++) {
			if (adjMatrix[index][i] != INFINITY)
				list.add(vertices[i]);
		}
		return list;
	}

}
