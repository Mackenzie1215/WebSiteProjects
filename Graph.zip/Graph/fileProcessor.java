package Graph;

import java.io.File;
import java.util.List;
import java.util.Scanner;

public class fileProcessor {

	@SuppressWarnings("unused")
	public static void main(String[] args) throws Exception {
		// Read file map.dat and break down to create a graph of williamsport
		File file = new File("map.dat");

		@SuppressWarnings("resource")
		Scanner sc = new Scanner(file);

		WDGraph<String> williamsport;
		double[][] longLat = new double[25][5];
		String[] name = new String[25];

		// create our graph for Williamsport
		williamsport = new WDGraph<String>();
		List<String> list;
		// outprint the first line of file
		System.out.println("Mackenzie Hagerty \nGraph project \nCIT Data Structure Analysis");

		// num of verticies
		String numV = sc.nextLine();

		// runs through the vertices
		for (int i = 0; i < Integer.parseInt(numV); i++) {

			String line = sc.nextLine();
			String[] arr = line.split(",");
			name[i] = arr[4];
			// add our street intersection names to graph
			williamsport.addVertex(arr[4]);

			// keep our long and lat to calculate distance
			longLat[i][0] = Double.parseDouble(arr[0]);
			longLat[i][1] = Double.parseDouble(arr[1]);
			longLat[i][2] = Double.parseDouble(arr[2]);

		}
		// num of edges
		String numE = sc.nextLine();

		// runs through the edges
		for (int i = 0; i < Integer.parseInt(numE); i++) {

			String line = sc.nextLine();
			String[] arr = line.split(" ");

			// getting distance in feet from one spot to another
			double lat1 = longLat[Integer.parseInt(arr[0])][2];
			double lat2 = longLat[Integer.parseInt(arr[1])][2];
			double long1 = longLat[Integer.parseInt(arr[0])][1];
			double long2 = longLat[Integer.parseInt(arr[1])][1];
			// run distance method
			double tD = distance(lat1, long1, lat2, long2, "M");
			// convert miles to feet for good even numbers
			double D = tD * 5280;

			// add the edge
			williamsport.addEdge(name[Integer.parseInt(arr[0])], name[Integer.parseInt(arr[1])], (int) D);

			// if its a two way we flip it and add another edge to show it can go both ways
			if (Integer.parseInt(arr[2]) == 2) {
				williamsport.addEdge(name[Integer.parseInt(arr[1])], name[Integer.parseInt(arr[0])], (int) D);
			}

		}

		// How many problems we must solve
		String numP = sc.nextLine();

		// runs through our problems we must solve
		for (int i = 0; i < Integer.parseInt(numP); i++) {
			String line = sc.nextLine();
			String[] arr = line.split(" ");
			String origin = (name[Integer.parseInt(arr[0])]);
			String destination = (name[Integer.parseInt(arr[1])]);
//if a path exists between the two run the shortest path algorithm
			if (williamsport.existPath(origin, destination)) {
				williamsport.shortestPath(origin, destination);
			} else
				System.out.printf("there is no path between %s and %s\n", origin, destination);
		}
		sc.reset();
	}

	private static double distance(double lat1, double lon1, double lat2, double lon2, String unit) {
		if ((lat1 == lat2) && (lon1 == lon2)) {
			return 0;
		} else {
			double theta = lon1 - lon2;
			double dist = Math.sin(Math.toRadians(lat1)) * Math.sin(Math.toRadians(lat2))
					+ Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) * Math.cos(Math.toRadians(theta));
			dist = Math.acos(dist);
			dist = Math.toDegrees(dist);
			dist = dist * 60 * 1.1515;
			return (dist);
		}
	}
}
